//
//  Group.m
//  RatingVolsu-iOS-ObjC
//
//  Created by Настя on 10.10.14.
//  Copyright (c) 2014 VolSU. All rights reserved.
//

#import "Group.h"
#import "Faculty.h"
#import "FavoritesItem.h"
#import "Student.h"


@implementation Group

@dynamic groupId;
@dynamic name;
@dynamic year;
@dynamic faculty;
@dynamic favoritesItems;
@dynamic students;

@end
