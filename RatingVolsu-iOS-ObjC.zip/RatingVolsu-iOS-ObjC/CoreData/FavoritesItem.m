//
//  FavoritesItem.m
//  RatingVolsu-iOS-ObjC
//
//  Created by Настя on 10.10.14.
//  Copyright (c) 2014 VolSU. All rights reserved.
//

#import "FavoritesItem.h"
#import "Group.h"
#import "Student.h"


@implementation FavoritesItem

@dynamic favoritesId;
@dynamic semestr;
@dynamic group;
@dynamic student;

@end
