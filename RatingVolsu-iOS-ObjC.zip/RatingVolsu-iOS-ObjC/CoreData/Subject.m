//
//  Subject.m
//  RatingVolsu-iOS-ObjC
//
//  Created by Настя on 10.10.14.
//  Copyright (c) 2014 VolSU. All rights reserved.
//

#import "Subject.h"
#import "RatingItem.h"


@implementation Subject

@dynamic subjectId;
@dynamic name;
@dynamic type;
@dynamic ratingItems;

@end
