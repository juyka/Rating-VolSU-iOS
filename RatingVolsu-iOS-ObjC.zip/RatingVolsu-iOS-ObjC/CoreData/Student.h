//
//  Student.h
//  RatingVolsu-iOS-ObjC
//
//  Created by Настя on 10.10.14.
//  Copyright (c) 2014 VolSU. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class FavoritesItem, Group, RatingItem;

@interface Student : NSManagedObject

@property (nonatomic, retain) NSNumber * studentId;
@property (nonatomic, retain) NSString * number;
@property (nonatomic, retain) NSSet *favoritesItems;
@property (nonatomic, retain) Group *group;
@property (nonatomic, retain) NSSet *ratingItems;
@end

@interface Student (CoreDataGeneratedAccessors)

- (void)addFavoritesItemsObject:(FavoritesItem *)value;
- (void)removeFavoritesItemsObject:(FavoritesItem *)value;
- (void)addFavoritesItems:(NSSet *)values;
- (void)removeFavoritesItems:(NSSet *)values;

- (void)addRatingItemsObject:(RatingItem *)value;
- (void)removeRatingItemsObject:(RatingItem *)value;
- (void)addRatingItems:(NSSet *)values;
- (void)removeRatingItems:(NSSet *)values;

@end
