//
//  RatingItem.m
//  RatingVolsu-iOS-ObjC
//
//  Created by Настя on 10.10.14.
//  Copyright (c) 2014 VolSU. All rights reserved.
//

#import "RatingItem.h"
#import "Student.h"
#import "Subject.h"


@implementation RatingItem

@dynamic exam;
@dynamic firstAttestation;
@dynamic ratingId;
@dynamic secondAttestation;
@dynamic semestr;
@dynamic sum;
@dynamic thirdAttestation;
@dynamic total;
@dynamic student;
@dynamic subject;

@end
