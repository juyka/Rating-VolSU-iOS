//
//  Faculty.m
//  RatingVolsu-iOS-ObjC
//
//  Created by Настя on 10.10.14.
//  Copyright (c) 2014 VolSU. All rights reserved.
//

#import "Faculty.h"
#import "Group.h"


@implementation Faculty

@dynamic facultyId;
@dynamic name;
@dynamic groups;

@end
