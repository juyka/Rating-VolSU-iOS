//
//  Student.m
//  RatingVolsu-iOS-ObjC
//
//  Created by Настя on 10.10.14.
//  Copyright (c) 2014 VolSU. All rights reserved.
//

#import "Student.h"
#import "FavoritesItem.h"
#import "Group.h"
#import "RatingItem.h"


@implementation Student

@dynamic studentId;
@dynamic number;
@dynamic favoritesItems;
@dynamic group;
@dynamic ratingItems;

@end
