//
//  RequestManager.m
//  RatingVolsu-iOS-ObjC
//
//  Created by Настя on 11.10.14.
//  Copyright (c) 2014 VolSU. All rights reserved.
//

#import "RequestManager.h"
#import "AFNetworking/AFNetworking.h"
@import Foundation;

@implementation RequestManager

+ (instancetype)manager {
	
	static RequestManager *manager;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		
		manager = [[self alloc] init];
	});
	
	return manager;
}

- (void)facultyListWithHandler:(RequestHandler)handler {
	
	NSString *urlString = @"http://umka.volsu.ru/newumka3/viewdoc/service_selector/";
	
	NSURL *url = [NSURL URLWithString:urlString];
	NSDictionary *parameters = @{ @"fak_id": @"3"};
	AFHTTPSessionManager *sessionManager = [[AFHTTPSessionManager alloc] initWithBaseURL:url];

	sessionManager.responseSerializer = [AFJSONResponseSerializer serializer];
	sessionManager.responseSerializer.acceptableContentTypes = [sessionManager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
	sessionManager.responseSerializer.stringEncoding = 4;
	
	[sessionManager POST:@"group_req.php" parameters:parameters success:^(NSURLSessionDataTask *task, id responseObject) {
		
		NSLog(@"%@", responseObject);
		
	} failure:^(NSURLSessionDataTask *task, NSError *error) {
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error Retrieving Weather"
															message:[error localizedDescription]
														   delegate:nil
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
	}];

}

@end
